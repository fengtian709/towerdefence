#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPixmap>
#include<QPainter>
#include<QPaintEvent>
#include<QPushButton>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    this->setFixedSize(1200,900);
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::paintEvent(QPaintEvent*){
setWindowTitle("塔防游戏");
QPainter painter(this);
QPixmap pixmap(":/res/initial.jpeg");
painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}
