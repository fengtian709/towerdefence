#ifndef MYBUTTON2_H
#define MYBUTTON2_H

#include<QObject>
#include<QPixmap>
#include<QPoint>
#include<QPushButton>
#include<QAction>
class myButton2 : public QPushButton
{
    Q_OBJECT
public:
    myButton2(QString fileName);
private:
    QPixmap pixmap;


signals:
    void chooseHello();
};

#endif // MYBUTTON2_H
