#include "myobject.h"

myObject::myObject(QPoint startPos,QPoint targetPos,QString fileName) : QObject(0),pixmap(fileName)
{
   this->currentPos=startPos;
   this->startPos=startPos;
   this->targetPos=targetPos;
}

void myObject::draw(QPainter*painter){
    painter->drawPixmap(currentPos,pixmap);
}

void myObject::move(){
    QPropertyAnimation*animation=new QPropertyAnimation(this,"currentPos");
    animation->setDuration(2000);
    animation->setStartValue(startPos);
    animation->setEndValue(targetPos);
    animation->start();
}

QPoint myObject::getCurrentPos(){
    return this->currentPos;
}

void myObject::setCurrentPos(QPoint pos){
    this->currentPos=pos;
}
