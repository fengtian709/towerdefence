#include "monster.h"
#include<stdio.h>
monster::monster()
{
    m_monster.load(":/res/flower1.png");
    //加载怪物图片
    m_x=0;
    m_y=400;
    //初始化怪物坐标
}

void monster::setPosition(int x, int y)
{
    m_x=x;
    m_y=y;
}
