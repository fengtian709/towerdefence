#include "tower.h"
#include<QPoint>
#include<QPixmap>
#include<QPainter>
tower::tower(QPoint pos,QString pixFileName) : QObject(0),pixmap(pixFileName)
{
    _pos=pos;
}
void tower::draw(QPainter*painter){
    painter->drawPixmap(_pos,pixmap);
}
