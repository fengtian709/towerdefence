#include "mybutton.h"
#include<QPixmap>
#include<QPropertyAnimation>
myButton::myButton(QString pix):QPushButton(0){
    QPixmap pixmap(pix);
    this->setFixedSize(pixmap.width(),pixmap.width());
    this->setStyleSheet("QPushButton{border:Opx;}");
    this->setIcon(pixmap);
    this->setIconSize(QSize(pixmap.width(),pixmap.height()));
}
void myButton::jumpdown(){
    QPropertyAnimation*animation=new QPropertyAnimation(this,"geometry");
    animation->setDuration(200);
    //设置动画的时间间隔
    animation->setStartValue(QRect(this->x(),this->y(),this->width(),this->height()));
    //起始位置
    animation->setEndValue(QRect(this->x(),this->y()+15,this->width(),this->height()));
    //结束位置
    animation->setEasingCurve(QEasingCurve::OutBounce);
    //设置弹跳曲线
    animation->start();
    //执行动画
}
void myButton::jumpup(){
    QPropertyAnimation*animation=new QPropertyAnimation(this,"geometry");
    animation->setDuration(200);
    animation->setStartValue(QRect(this->x(),this->y()+15,this->width(),this->height()));
    animation->setEndValue(QRect(this->x(),this->y(),this->width(),this->height()));
    animation->setEasingCurve(QEasingCurve::OutBounce);
    animation->start();
}
