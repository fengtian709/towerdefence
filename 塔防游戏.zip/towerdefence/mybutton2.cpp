#include "mybutton2.h"
#include<QSize>
myButton2::myButton2(QString fileName):QPushButton(0),pixmap(fileName){
    this->setFixedSize(pixmap.width(),pixmap.height());
    this->setStyleSheet("QPushButton{border:Opx;}");
    this->setIcon(pixmap);
    this->setIconSize(QSize(pixmap.width(),pixmap.height()));
    this->setContextMenuPolicy(Qt::ActionsContextMenu);
    QAction*action1=new QAction(this);
    action1->setText("hello");
    this->addAction(action1);
    connect(action1,&QAction::triggered,this,[=](){
        emit chooseHello();
    });
}
