#ifndef MYBUTTON_H
#define MYBUTTON_H

#include <QWidget>
#include<QPushButton>
class myButton : public QPushButton
{
    Q_OBJECT
public:
   myButton(QString pix);
   void jumpdown();
   void jumpup();
signals:

};

#endif // MYBUTTON_H
