#ifndef MYWINDOW_H
#define MYWINDOW_H

#include <QMainWindow>
#include"tower.h"
#include<QList>
#include"myobject.h"
#include"myobject2.h"
class myWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit myWindow(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);
    void set_tower();
    void addmyObject();
    void updateScene();
    void showInfo(QPainter*painter);
    private:
    QList<tower*>tower_list;
    QList<myObject*>object_list;
    QList<myObject2*>object2_list;
    int num1=10;
    int num2=20;
signals:
    void chooseBack();

};

#endif // MYWINDOW_H
