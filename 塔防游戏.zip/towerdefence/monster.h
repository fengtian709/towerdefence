#ifndef MONSTER_H
#define MONSTER_H

#include<QPixmap>
#include<QRect>

class monster
{
public:
    monster();

    void setPosition(int x,int y);
    //设置怪物位置
public:
    QPixmap m_monster;
    //怪物资源对象
    int m_x;
    int m_y;
    //怪物坐标

};

#endif // MONSTER_H
