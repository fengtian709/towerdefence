#ifndef MYOBJECT2_H
#define MYOBJECT2_H

#include<QObject>
#include<QPoint>
#include<QPixmap>

class myObject2 : public QObject
{
    Q_OBJECT
public:
    myObject2(QPoint startPos,QPoint targetPos,QString fileName);
    void move();
    void draw(QPainter*painter);
private:
    QPoint startPos;
    QPoint targetPos;
    QPoint currentPos;
    QPixmap pixmap;
    qreal speed;
signals:

};

#endif // MYOBJECT2_H
