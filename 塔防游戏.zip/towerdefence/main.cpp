#include "mainwindow.h"
#include<QResource>
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QResource::registerResource(":/res/fire.png");

    MainWindow w;
    w.show();

    return a.exec();
}
