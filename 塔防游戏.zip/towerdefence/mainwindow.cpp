#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPixmap>
#include<QPainter>
#include<QPaintEvent>
#include<QPushButton>
#include<QDebug>
#include<QTimer>
#include"mybutton.h"
#include"mywindow.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    this->setFixedSize(1200,900);
    ui->setupUi(this);
    myButton*btn=new myButton(":/res/button.png");
    btn->setParent(this);
    btn->move(60,60);
    myWindow*scene=new myWindow;
    connect(btn,&QPushButton::clicked,this,[=](){
        btn->jumpdown();
        btn->jumpup();
        QTimer::singleShot(500,this,[=](){
            this->close();
            scene->show();
        });
    });
    connect(scene,&myWindow::chooseBack,this,[=](){
        scene->hide();
        this->show();
    });
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::paintEvent(QPaintEvent*){
setWindowTitle("塔防游戏");
setWindowIcon(QIcon(":/res/fire.png"));
QPainter painter(this);
QPixmap pixmap(":/res/initial.jpeg");
painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}
