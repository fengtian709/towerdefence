#include "mywindow.h"
#include"mybutton.h"
#include<QPainter>
#include<QTimer>
#include<myobject2.h>
#include<QDebug>
myWindow::myWindow(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(1200,900);
    myButton*back_btn=new myButton(":/res/button.png");
    back_btn->setParent(this);
    back_btn->move(0,350);
    myButton*settower=new myButton(":/res/button.png");
    settower->setParent(this);
    settower->move(1200,350);
    connect(settower,&myButton::clicked,this,&myWindow::addmyObject);
    connect(back_btn,&myButton::clicked,this,[=](){
       emit chooseBack();
     });
    QTimer*timer=new QTimer(this);
    connect(timer,&QTimer::timeout,this,&myWindow::updateScene);
    timer->start(10);

}
//加载出游戏场景的按钮
void myWindow::paintEvent(QPaintEvent *){
    setWindowTitle("塔防游戏");
    setWindowIcon(QIcon(":/res/fire.png"));
    QPainter painter(this);
    QPixmap pixmap(":/res/beijingtu.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
    showInfo(&painter);
    foreach(tower*tower,tower_list)
        tower->draw(&painter);
    foreach(myObject*object,object_list)
        object->draw(&painter);
    foreach(myObject2*object,object2_list)
        object->draw(&painter);
}
//游戏场景的界面

void myWindow::set_tower(){
    tower*a_new_tower=new tower(QPoint(1200,350),":/res/firedragon1.png");
    tower_list.push_back(a_new_tower);
    update();
}

void myWindow::addmyObject(){
    myObject2*object=new myObject2(QPoint(0,350),QPoint(1200,350),":/res/position.png");
    object2_list.push_back(object);
    object->move();
    update();
}

void myWindow::updateScene(){
    foreach(myObject2*object,object2_list)
    object->move();
    update();
}

void myWindow::showInfo(QPainter *painter){
    painter->save();
    painter->setPen(Qt::red);
    painter->drawText(QRect(200,200,200,100),QString("num1:%1 num2:%2").arg(num1).arg(num2));
    painter->restore();
}
