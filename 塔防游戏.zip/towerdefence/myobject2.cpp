#include "myobject2.h"
#include<QPoint>
#include<QVector2D>
#include<QPainter>
myObject2::myObject2(QPoint startPos,QPoint targetPos,QString fileName) : QObject(0),pixmap(fileName)
{
   this->currentPos=startPos;
   this->startPos=startPos;
   this->targetPos=targetPos;
    speed=1.5;
}

void myObject2::move(){
    QVector2D vector(targetPos-startPos);
    vector.normalize();
    currentPos=currentPos+vector.toPoint()*speed;

}

void myObject2::draw(QPainter*painter){
    painter->drawPixmap(currentPos,pixmap);
}
